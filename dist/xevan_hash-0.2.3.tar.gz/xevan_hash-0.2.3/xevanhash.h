#ifndef xevanHASH_H
#define xevanHASH_H

#ifdef __cplusplus
extern "C" {
#endif

void xevan_hash(const char* input, int size, char* output);

#ifdef __cplusplus
}
#endif

#endif
