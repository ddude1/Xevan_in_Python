# xevan_in_Python
python implementation of xevan hashing algo.
It is not pure python, it is c extented python due to performance.

This is Enhacement from original LIMXTEC version that is customsed to work for xevan_hashes 
with Version one block at 80 bytes and varibale block header size
